# -*- coding: utf-8 -*-
"""
Created on Fri Apr 20 11:26:49 2018

@author: hb65402
"""
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp

ML = True

Nx = Ny = 11
x = np.linspace(0, 1, Nx)
y = np.linspace(0, 1, Ny)
X, Y = np.meshgrid(x, y)
print ('x = y = \n', x)
print ('X = \n', X)
print ('Y = \n', Y)
# plot X
plt.figure(4,dpi=300)
plt.clf()
plt.imshow(X)
plt.title('X grid $(X_{i,j})_{i,j}$')
plt.xlabel(r'$j$')
plt.ylabel(r'$i$')
plt.colorbar()
plt.savefig('fig05-04.pdf')
plt.figure(5)
plt.clf()
plt.imshow(Y)
plt.title('Y grid $(Y_{i,j})_{i,j}$')
plt.xlabel(r'$j$')
plt.ylabel(r'$i$')
plt.colorbar()
plt.savefig('fig05-05.pdf')

# Create a 3x3 array
T = np.arange(9).reshape(3,3)
# Flatten the array
U = T.flatten()
# Reshape the array and check that we get back T
Tnew = U.reshape(3,3)
assert np.all(Tnew == T)
# Print T, U and Tnew
print ('T = \n', T)
print ("U = T.flatten() = \n", U)
print ("T = U.reshape(3,3) = \n", Tnew)
B = np.array([[-4, 1, 0], [ 1, -4, 1], [ 0, 1, -4]])

                  
N = 50
nblock = N - 2
Bdiag = -4 * np.eye(nblock)
Bupper = np.diag([1] * (nblock - 1), 1)
Blower = np.diag([1] * (nblock - 1), -1)
B = Bdiag + Bupper + Blower
# Creat a list [B,B,B,...,B] with nblock Bs
blst = [B] * nblock
# Unpack the list of diagonal blocks ’blst’
# since block_diag expects each block to be passed as separate
# arguments. This is the same as doing block_diag(B,B,B,...,B)
A = sp.linalg.block_diag(*blst)
# Upper diagonal array offset by nblock: we’ve got (nblock-1) I blocks
# each containing nblock ones
Dupper = np.diag(np.ones(nblock * (nblock - 1)), nblock)
# Lower diagonal array offset by -nblock
Dlower = np.diag(np.ones(nblock * (nblock - 1)), -nblock)

#A = sp.linalg.block_diag(B, B, B)
# Upper diagonal array offset by 3
#Dupper = np.diag(np.ones(3 * 2), 3)
# Lower diagonal array offset by -3
#Dlower = np.diag(np.ones(3 * 2), -3)

D = Dupper + Dlower
np.add(A,D,out=A,casting='unsafe')
print ("A = \n", A)
Te = 100

b = np.zeros(nblock**2)
b[:nblock] = -Te
#print "b = \n", b
#
#b = np.zeros(9)
#b[0] = -Te
#b[1] = -Te
#b[2] = -Te
print ("b = \n", b)

u = sp.linalg.solve(A, b)
#T = u.reshape((3,3))
T = u.reshape((nblock, nblock))

print ("T = \n", T)
def embed(T, Te=100):
    N = T.shape[0] + 2
    Tfull = np.zeros((N,N))
    Tfull[0] = Te
    Tfull[1:-1, 1:-1] = T
    return Tfull
Tfull = embed(T)
print(Tfull)
x = y = np.linspace(0, 1, N)
X, Y = np.meshgrid(x,y)
plt.figure(9,dpi=300)
plt.clf()
plt.pcolor(X, Y, Tfull,edgecolors='black',snap='True')
plt.axis('scaled')
plt.colorbar()
plt.xlabel('x')
plt.ylabel('y')
plt.title('T(x,y) on %dx%d grid' % (N,N))

#print ("Tfull = \n", Tfull)
#x = y = np.linspace(0, 1, 5)
#X, Y = np.meshgrid(x,y)
#plt.figure(8)
#plt.clf()
#plt.pcolor(X, Y, Tfull)
#plt.axis('scaled')
#plt.colorbar()
plt.savefig('fig05-08.pdf')

########################################################ML
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior() 
#import tensorflow as tf
import numpy as np

if ML==True:
    #data = np.genfromtxt('Burgers.csv', delimiter=',', names=['Seq','X1','t1','X2','t2','X3','t3','X4','t4','Y'])
    data = np.genfromtxt('xlocation.csv', delimiter=',', names=['Seq','X1','X2','X4'])
    # Forming numpy arrays
    # Note: At Seq 23037, the JobTime is reset
    #t1 = np.array(data['JobTime']).astype(np.float64)[1:37525]
    #t2 = np.array(data['JobTime']).astype(np.float64)[37525:]
    #t2 = t2 + t1[t1.shape[0] - 1]
    #t = np.concatenate((t1, t2))
    seq = np.array(data['Seq']).astype(np.float64)[1:]
    x1 = np.asarray(data['X1']).astype(np.float)[1:]
#    t1 = np.asarray(data['t1']).astype(np.float)[1:]
    x2 = np.asarray(data['X2']).astype(np.float)[1:]
#    t2 = np.asarray(data['t2']).astype(np.float)[1:]       
#    x3 = np.asarray(data['X3']).astype(np.float)[1:]
#    t3 = np.asarray(data['t3']).astype(np.float)[1:]  
    x4 = np.asarray(data['X4']).astype(np.float)[1:]
#    t4 = np.asarray(data['t4']).astype(np.float)[1:]                  
#    a = np.asarray(data['A']).astype(np.float)[1:]   
#    Y = np.asarray(data['Y']).astype(np.float)[1:]
    #train_X = (np.c_[x1, t1])
    train_X = (np.c_[x1])
    #train_X = (np.c_[x1, t1])
    train_Xbc2 = (np.c_[x2])
#    train_Xic =  (np.c_[x3])
    train_Xbc1 = (np.c_[x4])
    #train_Y = np.c_[Y]
             
    #train_X = np.asarray([[0.25,0.4],[0.25,0.6],[0.25,0.8],[0.25,1]])
    #train_Y = np.asarray([[0.01357],[0.00189],[0.00026],[0.00004]])
    #train_Xic = np.asarray([[0.25,0.],[0.4,0.],[0.6,0.],[0.8,0.]])
    #train_Xbc = numpy.asarray([[1,0.],[1,0.],[1,0.],[1,0]])
    nnodes1 = 8
    nnodes2 = 11
    beta = 0.0
    x = tf.placeholder("float",[None, 1])
    yac = tf.placeholder("float",[None, 1])
    
    W = tf.Variable(tf.zeros([1, 1]))
    b = tf.Variable(tf.zeros([1, 1]))
    
    W1 = tf.Variable(tf.zeros([1,nnodes1]))
    
    b1 = tf.Variable(tf.zeros([nnodes1]))
    
    #W2 = tf.Variable(tf.zeros([nnodes1,nnodes2]))
    #b2 = tf.Variable(tf.zeros([nnodes2]))
    
    W3 = tf.Variable(tf.zeros([nnodes1,1]))
    b3 = tf.Variable(tf.zeros([1]))
    
    
    #init = tf.initialize_all_variables()
    
    layer1 = tf.nn.sigmoid(tf.matmul(x,W1) + b1)
    #layer2 = tf.nn.sigmoid(tf.matmul(layer1,W2) + b2)
    y = tf.matmul(layer1,W3) + b3
    
    #layer1dert = tf.nn.sigmoid(tf.matmul(x,W1) + b1)*(1 - tf.nn.sigmoid(tf.matmul(x,W1) + b1))*W1[1]
    #
    #yt = tf.matmul(layer1dert,W3)  
    #
    layer1derx = tf.nn.sigmoid(tf.matmul(x,W1) + b1)*(1 - tf.nn.sigmoid(tf.matmul(x,W1) + b1))*W1[0]
    yx = tf.matmul(layer1derx,W3) 
    #
    layer1derxx = (layer1derx - 2*tf.nn.sigmoid(tf.matmul(x,W1) + b1)*layer1derx)*W1[0]
    yxx = tf.matmul(layer1derxx,W3) 
    #
    #
    #xic = tf.placeholder("float",[None, 1])
    #layer1ic = tf.nn.sigmoid(tf.matmul(xic,W1) + b1)
    #layer2ic = tf.nn.sigmoid(tf.matmul(layer1ic,W2) + b2)
    #yic = tf.matmul(layer1ic,W3) + b3 - tf.sin(3.14*xic[0])
    #yic = tf.matmul(layer1ic,W3) + b3 
    #
    xbc1 = tf.placeholder("float",[None, 1])
    layer1bc = tf.nn.sigmoid(tf.matmul(xbc1,W1) + b1)
    #layer2bc = tf.nn.sigmoid(tf.matmul(layer1bc,W2) + b2)
    ybc1 = tf.matmul(layer1bc,W3) + b3
    
    layer1derxbc = tf.nn.sigmoid(tf.matmul(xbc1,W1) + b1)*(1 - tf.nn.sigmoid(tf.matmul(xbc1,W1) + b1))*W1[0]
    #ybc1x = tf.matmul(layer1derx,W3) 
    #
    xbc2 = tf.placeholder("float",[None, 1])
    layer1bc = tf.nn.sigmoid(tf.matmul(xbc2,W1) + b1)
    #layer2bc = tf.nn.sigmoid(tf.matmul(layer1bc,W2) + b2)
    ybc2 = tf.matmul(layer1bc,W3) + b3
    
    
    #x1 = 1+tf.exp(-(W3[0]*x[0]+b3))
    
    #x2 = 1/x1-tf.sin(3.14*x[0])
    #x3 = 1+tf.exp(-(W3[1]*x[1]+b))
    #x4 = 1+tf.exp(-(W3[0]+b+W3[1]*x[1]))
    #activation = tf.nn.sigmoid(tf.matmul(x, W)+b)
    #cost = (tf.square(activation *(1-activation)*-W[1]+activation*activation *(1-activation)*-W[0]
                                   #+1.0*W[0]*(1-2*activation)))+x2*x2+1/(x3*x3)+1/(x4*x4)
    #cost = tf.square(yt-y*yx-yxx)+tf.square(yic)+tf.square(ybc1)+tf.square(ybc2)
    regularizers = tf.nn.l2_loss(W1)
    cost = tf.reduce_mean(tf.square(yxx)+tf.square(ybc1-1)+tf.square(ybc2))
    cost = tf.reduce_mean(cost + beta * regularizers)
    #cost = tf.reduce_mean(tf.square(yx)+tf.square(ybc1-1)+tf.square(ybc2-1))
    #+(1./(1.+ tf.exp(-(W[0]*x[0]+b)))-tf.sin(3.14*x[0]))^2
    #+tf.square(tf.nn.sigmoid(W[0]*x[0]+b[0]))+
    #tf.square(1./(1.+ exp(-(W[0]*x[0]+b[0]))
    step = tf.Variable(0,trainable=False)
    rate = tf.train.exponential_decay(1., step, 30, 0.99)
    tf.summary.scalar('learning_rate', rate)
    #optimizer = tf.train.AdamOptimizer(rate,epsilon=1.e-5).minimize(cost, global_step = step)
    optimizer = tf.train.AdamOptimizer(0.1).minimize(cost)
    init = tf.initialize_all_variables()
    errors = []
    with tf.Session() as sess:
        sess.run(init)
        for i in range(2000):
            #train_data = sess.run(optimizer, feed_dict={x: train_X, xbc2:train_Xbc2, xic:train_Xic, xbc1:train_Xbc1})
            # _, error_value = sess.run([optimizer, cost], feed_dict={x: train_X, yac:train_Y, xic:train_Xic, xbc1:train_Xbc1, xbc2:train_Xbc2})
             _, error_value = sess.run([optimizer, cost], feed_dict={x: train_X, xbc1:train_Xbc1, xbc2:train_Xbc2})
             errors.append(error_value)
             result = sess.run(y, feed_dict={x:train_X})
             
             np.savetxt("result.csv",np.array(result))
        np.savetxt("cost.csv",np.array(errors))
    import numpy as np
    from math import exp as exp
#    u_analytical = np.zeros(len(result))
#    NU = 0.01
#       # Analytical Solution
#    for n in range(0,len(result)):
#           
#               phi = tf.exp( -(x[n]-4*t1[n])**2/(4*NU*(t1[n]+1)) ) + tf.exp( -(x[n]-4*t1[n]-2*3.14)**2/(4*NU*(t1[n]+1)) )
#    
#               dphi = ( -0.5*(x[i]-4*t1[n])/(NU*(t1[n]+1))*tf.exp( -(x[i]-4*t1[n])**2/(4*NU*(t1[n]+1)) )
#                   -0.5*(x[i]-4*t1[n]-2*3.14)/(NU*(t1[n]+1))*tf.exp( -(x[i]-4*t1[n]-2*3.14)**2/(4*NU*(t1[n]+1)) ) )
#    
#               #u_analytical[n] = -2*NU*(dphi/phi) + 4
#               #u_analytical[n] = (exp(x1[n]*NU) - exp(NU))/(1-NU-exp(NU))
#               u_analytical[n] = 1*(1-x1[n])
    
    import matplotlib.pyplot as plt
#    plt.figure(dpi=300)
#    ax=plt.subplot(111)
       
       
#    ax.plot(x1,result,'ko', markerfacecolor='none', alpha=0.5, label=' numerical')
#    ax.plot(x1,u_analytical,linestyle='-',label=' analytical')
#    ax.legend( bbox_to_anchor=(1.02,1), loc=2)
       
#    plt.xlabel('x ')
#    plt.ylabel('u ')
#    plt.ylim([0,1.0])
#    plt.xlim([0,1.0])
#    plt.xlabel('Iterations',fontsize=12)
#    plt.ylabel('Loss',fontsize=12)
#    plt.xticks(fontsize=12)
#    plt.yticks(fontsize=12)
#    plt.legend(prop={'size':10})
#    plt.show()
    Tfull[:,10]  = result.reshape((50,))*100
    Tfull[:,20]  = result.reshape((50,))*100
    Tfull[:,30]  = result.reshape((50,))*100
    Tfull[:,40]  = result.reshape((50,))*100
    del seq, x1, x2, x4
    sess.close()
    
    ############################################################
    x = y = np.linspace(0, 1, N)
    X, Y = np.meshgrid(x,y)
    plt.figure(9,dpi=300)
    plt.clf()
    plt.pcolor(X, Y, Tfull,edgecolors='black',snap='True')
    plt.axis('scaled')
    plt.colorbar()
    plt.xlabel('x')
    plt.ylabel('y')
    plt.title('T(x,y) on %dx%d grid' % (N,N))
    
    #print ("Tfull = \n", Tfull)
    #x = y = np.linspace(0, 1, 5)
    #X, Y = np.meshgrid(x,y)
    #plt.figure(8)
    #plt.clf()
    #plt.pcolor(X, Y, Tfull)
    #plt.axis('scaled')
    #plt.colorbar()
    plt.savefig('fig05-08.pdf')

