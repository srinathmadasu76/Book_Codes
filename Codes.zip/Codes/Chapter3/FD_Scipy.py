# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 08:19:15 2020

@author: HB65402
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score

L = 1
dx = 0.1
Pe = 10

  
Nx = int(round(L/dx))
x = np.linspace(0, L, Nx+1)    # mesh points in space
dx = x[1] - x[0]
u   = np.zeros(Nx+1)           # unknown u at new time level
u_analytical = np.zeros(Nx+1)
    
##################################################
# Data structures for the linear system
A = np.zeros((Nx+1, Nx+1))
b = np.zeros(Nx+1)

for i in range(1, Nx):
    A[i,i-1] = (1/(dx*dx)+Pe/(2*dx))
    A[i,i+1] = (1/(dx*dx)-Pe/(2*dx))
    A[i,i] = -2/(dx*dx)
A[0,0] = -1./dx-1.
A[0,1]= 1/dx
A[Nx,Nx] = 1.

# Set initial condition u(x,0) = I(x)

import scipy.linalg
    # Compute b and solve linear system
b[0] = -1
b[Nx] = 0
u[:] = scipy.linalg.solve(A, b)
print(u)
for i in range(Nx):
    u_analytical[i] = (np.exp(Pe*x[i])-np.exp(Pe))/(1-Pe-np.exp(Pe))
print(u_analytical)

# model evaluation
rmse = mean_squared_error(u,u_analytical)
r2 = r2_score(u_analytical,u)

# printing values
print('Root mean squared error: ', rmse)
print('R2 score: ', r2)

plt.figure(1)
plt.plot(u,'r-',label='Predicted',linewidth=2)
plt.plot(u_analytical,'b--',label='Actual')
plt.legend(prop={'size':10})
plt.show()