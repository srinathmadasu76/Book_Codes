# -*- coding: utf-8 -*-
"""
Created on Sat Feb  1 20:23:01 2020

@author: Srinath Madasu
"""

import numpy as np

# Define function
def f(x):
    return x*(1.0-x)
def gradf(x):
    return 1.0-2*x       
    # Newton-Raphson algorithm loop
nIter = 100
tol = 1e-8
x0 = 0.75 
for i in range(0,nIter):
    # Evaluate function at midpoint
    
    x = x0
    grad = gradf(x)
    
    x1 = x0 - f(x)/grad
    
    f1 = f(x1)
    print(x1)
    # Print
    print('Iter: %d, x: %f, f(x): %e' % (i+1, x1, f1))

    # Check for convergence
    if np.abs(f1) < tol:
        break
    else:
        # Update
        x0 = x1
        
if i == nIter - 1:        
    print('Method failed: Maximum number of iterations reached without convergence!')
else:
    print('Found a root at x = %f' % (x1))
    
