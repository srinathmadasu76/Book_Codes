# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 15:35:48 2020

@author: HB65402
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May 17 14:44:07 2018

@author: hb65402
"""

# -*- coding: utf-8 -*-
"""
Created on Tue May  8 08:57:01 2018

@author: hb65402
"""

import numpy
import pandas as pd
import matplotlib.pyplot as plt
from pandas import read_csv
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from pandas import DataFrame
from pandas import concat

# convert an array of values into a dataset matrix
def create_dataset(dataset, look_back=1):
    
    dataX, dataY = [], []
    
    for i in range(len(dataset)-look_back-1):
    
        
        a = dataset[i:(i+look_back), 0]
        
        dataX.append(a)
        
        dataY.append(dataset[i + look_back, 0])
        
        
    return numpy.array(dataX), numpy.array(dataY)

def series_to_supervised(data, n_in=1, n_out=1, dropnan=True):
	"""
	Frame a time series as a supervised learning dataset.
	Arguments:
		data: Sequence of observations as a list or NumPy array.
		n_in: Number of lag observations as input (X).
		n_out: Number of observations as output (y).
		dropnan: Boolean whether or not to drop rows with NaN values.
	Returns:
		Pandas DataFrame of series framed for supervised learning.
	"""
	n_vars = 1 if type(data) is list else data.shape[1]
	df = DataFrame(data)
	cols, names = list(), list()
	# input sequence (t-n, ... t-1)
	for i in range(n_in, 0, -1):
		cols.append(df.shift(i))
		names += [('var%d(t-%d)' % (j+1, i)) for j in range(n_vars)]
	# forecast sequence (t, t+1, ... t+n)
	for i in range(0, n_out):
		cols.append(df.shift(-i))
		if i == 0:
			names += [('var%d(t)' % (j+1)) for j in range(n_vars)]
		else:
			names += [('var%d(t+%d)' % (j+1, i)) for j in range(n_vars)]
	# put it all together
	agg = concat(cols, axis=1)
	agg.columns = names
	# drop rows with NaN values
	if dropnan:
		agg.dropna(inplace=True)
	return agg
 
 


# fix random seed for reproducibility
numpy.random.seed(7)
# load the dataset
df = pd.read_csv('Drilling.csv',header=0)
df = df[['WOB','RPM','Q','ROP']]
dataset = df.values
#dataset = dataset[0:3000]

dataset = dataset.astype('float32')
# normalize the dataset
scaler = MinMaxScaler(feature_range=(0, 1))
dataset = scaler.fit_transform(dataset)
look_back = 2
n_features = 4
n_obs = look_back*(n_features-1)+(n_features-1)
reframed = series_to_supervised(dataset, look_back, 1)
values = reframed.values
# split into train and test sets
train_size = int(len(values) * 0.67)
#train_size = 2000
test_size = len(values) - train_size

train, test = values[0:train_size,:], values[train_size:len(values),:]

# reshape into X=t and Y=t+1

trainX, trainY = train[:, :n_obs], train[:, -1]
testX, testY = test[:, :n_obs], test[:, -1]

# reshape input to be [samples, time steps, features]
trainX = numpy.reshape(trainX, (trainX.shape[0], look_back+1, n_features-1))
testX = numpy.reshape(testX, (testX.shape[0], look_back+1, n_features-1))
# create and fit the LSTM network
model = Sequential()
model.add(LSTM(8, return_sequences=True, input_shape=(trainX.shape[1], trainX.shape[2])))
model.add(LSTM(4))
model.add(Dense(1))
model.compile(loss='mean_squared_error', optimizer='adam')
model.fit(trainX, trainY, epochs=200, batch_size=16, verbose=2)
# make predictions
trainPredict = model.predict(trainX)
testPredict = model.predict(testX)

# invert predictions
trainX = trainX.reshape((trainX.shape[0], n_obs))

n_f = n_features - 1
# invert scaling for forecast
inv_ypred = numpy.concatenate((trainX[:,-n_f:],trainPredict), axis=1)

inv_ypred = scaler.inverse_transform(inv_ypred)
inv_ypred = inv_ypred[:,n_f]
# invert scaling for actual
trainY = trainY.reshape((len(trainY), 1))
predY = numpy.concatenate((trainX[:,-n_f:],trainY), axis=1)
predY = scaler.inverse_transform(predY)
predY = predY[:,n_f]
# make a prediction

testX = testX.reshape((testX.shape[0], n_obs))

# invert scaling for forecast
inv_yhat = numpy.concatenate((testX[:,-n_f:],testPredict), axis=1)

inv_yhat = scaler.inverse_transform(inv_yhat)
inv_yhat = inv_yhat[:,n_f]
# invert scaling for actual
testY = testY.reshape((len(testY), 1))
invY = numpy.concatenate((testX[:,-n_f:],testY), axis=1)
invY = scaler.inverse_transform(invY)
invY = invY[:,n_f]
# calculate RMSE
rmse = math.sqrt(mean_squared_error(invY, inv_yhat))
print('Test RMSE: %.8f' % rmse)

inv_ypred = inv_ypred.reshape((len(inv_ypred), 1))
predY = predY.reshape((len(predY), 1))
inv_yhat = inv_yhat.reshape((len(inv_yhat), 1))
invY = invY.reshape((len(invY), 1))
plotpredY = numpy.concatenate((inv_ypred, predY), axis=1)
plotactY = numpy.concatenate((inv_yhat, invY), axis=1)

trainPredictPlot = numpy.empty([len(dataset[:,0]),2])
trainPredictPlot[:, :] = numpy.nan
trainPredictPlot[look_back:len(plotpredY)+look_back, :] = plotpredY

testPredictPlot = numpy.empty([len(dataset[:,0]),2])
testPredictPlot[:, :] = numpy.nan
testPredictPlot[len(plotpredY)+look_back-1:len(dataset)-1, :] = plotactY

plotpredY = numpy.concatenate((inv_ypred, inv_yhat), axis=0)
plotactY =  numpy.concatenate((predY, invY), axis=0)
plt.figure(2)
plt.xlabel('Sample Point',fontsize=12)
plt.ylabel('ROP',fontsize=12)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.plot(inv_yhat,'r-',label='Predicted',linewidth=2)
plt.plot(invY,'b--',label='Actual')

plt.show()
